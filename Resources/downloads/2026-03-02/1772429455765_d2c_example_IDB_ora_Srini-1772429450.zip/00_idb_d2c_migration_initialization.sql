\i scripts/00_init_mig_execution.sql
\i scripts/30_validation_rules_dict.sql
\i scripts/40_dependency_validation_rules_dict.sql
\i scripts/40_gather_fallouts_dict.sql
