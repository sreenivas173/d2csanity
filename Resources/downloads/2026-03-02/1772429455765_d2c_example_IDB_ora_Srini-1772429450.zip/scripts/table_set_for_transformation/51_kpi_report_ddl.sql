
-- KPI_REPORT_DDL / KPI_REPORT
DROP TABLE IF EXISTS KPI_REPORT CASCADE
;

-- KPI_REPORT_DDL / KPI_REPORT
CREATE TABLE KPI_REPORT AS
select 
	domain as DOMAIN,
	be_entity as BE_ENTITY,
	be_entity_desc as BE_ENTITY_DESC,
	legacy_count as LEGACY_COUNT,
	sdb_count as SDB_COUNT,
	idb_count as IDB_COUNT,
	valid_idb_count as VALID_IDB_COUNT,
	cast (null as number) as TARGET_COUNT FROM (select * from KPI_BSS_CUSTOMER
union all
select * from KPI_BSS_INDIVIDUAL);

-- KPI_REPORT_DDL / KPI_REPORT
DO $$DECLARE
BEGIN
    EXECUTE $q$ alter table KPI_REPORT add (per_cent number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL) $q$;
END$$;
;
;

-- KPI_REPORT_DDL / KPI_REPORT
DO $$DECLARE
BEGIN
    EXECUTE $q$ alter table KPI_REPORT add (per_cent2 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL) $q$;
END$$;
;
;

-- KPI_REPORT_DDL / KPI_REPORT
DO $$DECLARE
BEGIN
    EXECUTE $q$ alter table KPI_REPORT add (per_cent3 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL) $q$;
END$$;
;
;
