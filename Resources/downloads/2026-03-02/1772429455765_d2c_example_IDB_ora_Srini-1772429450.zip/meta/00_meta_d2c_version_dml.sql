
-- META_D2C_VERSION_DML / META_D2C_VERSION
INSERT INTO META_D2C_VERSION (ID, VERSION, CREATED_BY, CREATED_WHEN, FILE_NAME)
(
SELECT 'd2c_example_IDB_ora_Srini.xlsx', '0.2', 'Liza', '12-04-24', 'input/d2c_example_IDB_ora_Srini-1772429450/d2c_example_IDB_ora_Srini.xlsx' FROM DUAL
)
;
COMMIT
;
