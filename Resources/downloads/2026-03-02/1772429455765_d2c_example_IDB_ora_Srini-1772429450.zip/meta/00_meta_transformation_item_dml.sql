
-- META_TRANSFORMATION_ITEM_DML / META_TRANSFORMATION_ITEM
INSERT INTO META_TRANSFORMATION_ITEM (VERSION_ID, PARENT_ID, SOURCE_ID, COLUMN_NAME, FIELD_DESCRIPTION, DATA_TYPE, TRANSFORMATION, LIST_VALUES, REFERENTIAL_ENTITY, REFERENTIAL_CLAUSE, EXTENDED_ATTRIBUTES)
(
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 16, 'SOURCE_ID', 'Primary Key ID. Additional migration attribute. ID in source system.', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 17, 'NAME', 'Customer Name', 'VARCHAR2(4000)', 'pd.NAME', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 18, 'CUSTOMER_CATEGORY_ID', 'Unique identifier of the Customer category. 
"id": "8bf02549-6fda-48b8-950d-32fadd4a8140",
"name": "B2C Client"', 'VARCHAR2(4000)', '''8bf02549-6fda-48b8-950d-32fadd4a8140''', 'Business;
Residential;
Employee;
VIP', NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 19, 'ENGAGED_PARTY_ID', 'Unique identifier of a Party on the basis of which the Customer was created', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 20, 'ENGAGED_PARTY_REF_TYPE', 'Engaged Party type. Value : Individual, Organization', 'VARCHAR2(4000)', '''Individual''', '''Individual''; ''Organization''', NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 21, 'STATUS', 'Used to track the lifecycle status of the Customer', 'VARCHAR2(4000)', 'pd.STATUS', 'Prospect
Activation Pending 
Active 
Former', NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 22, 'STATUS_REASON', 'Used for explanation on the value of the status lifecycle', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 23, 'EXTERNAL_ID', 'External Id of the Customer', 'VARCHAR2(4000)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 24, 'VALID_FROM', 'Record valid from', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 25, 'SOURCE_TIMESTAMP', 'Source timestamp', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 38, 'EXTENDED_ATTRIBUTES', 'Extended parameters', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 44, 'VALID_TO', 'Record valid to', 'TIMESTAMP(6)', 'NULL', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 1, 45, 'ID', 'ID', 'RAW(16)', 'NULL', NULL, NULL, NULL, '{"VALIDATE":""}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 15, 'SOURCE_ID', 'Primary Key ID', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 16, 'STATUS', 'Status of the Individual. For Migration it will be always Validated.', 'VARCHAR2(4000)', '''Validated''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 17, 'BIRTH_DATE', 'Birth date', 'TIMESTAMP(6)', 'pd.BIRTHDAY', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 18, 'GENDER', 'TO_BE_DEFINED', 'VARCHAR2(4000)', 'decode(pd.GENDER, ''M'', ''Male'', ''F'', ''Female'', null)', 'Female;
Male;
Unknown;
Not Applicable;', NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 19, 'LOCATION', 'Temporary current location of the individual (may be used if the individual has approved its sharing)', 'VARCHAR2(4000)', 'pd.LOCATION', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 20, 'SOURCE_TIMESTAMP', 'Additional migration attribute. Current snapshot''s timestamp in source system', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 26, 'IDB_CUSTOMER_ID', 'Internal : Technical Field for dependency validations', 'VARCHAR2(4000)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 27, 'EXTENDED_ATTRIBUTES', 'Extended parameters', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 30, 'NATIONALITY', 'Nationality', 'VARCHAR2(4000)', 'pd.COUNTRY', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 31, 'MARITAL_STATUS', 'Marital Status', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 32, 'PLACE_OF_BIRTH', 'Place Of Birth', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 2, 33, 'COUNTRY_OF_BIRTH', 'Country Of Birth', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 3, 13, 'REF_ID', 'Unique identifier of the related entity', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 3, 14, 'REF_TYPE', 'Type of the related entity, E.g.:
Individual;Organization.', 'VARCHAR2(4000)', '''Individual''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 3, 15, 'ISO_CODE', 'Language code in ISO format', 'VARCHAR2(4000)', '''ENG''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 3, 18, 'ROLE', 'Role', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 3, 19, 'ID', 'ID', 'RAW(16)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 16, 'SOURCE_ID', 'Primary Key ID', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID||''#''||rownum', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 17, 'REF_ID', 'Unique identifier of the related entity', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 18, 'REF_TYPE', 'Type of the related entity, E.g.:
Individual; Organization', 'VARCHAR2(4000)', '''Individual''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 19, 'IS_ACTIVE', 'Shows that contact is active
Default = TRUE', 'NUMBER(1,0)', '1', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 20, 'TYPE_OF_CONTACT_METHOD', 'Type of the contact method, such as: Email address, Telephone number, Postal address', 'VARCHAR2(4000)', '''Telephone number''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 21, 'TYPE_OF_CONTACT', 'Type of contact(home, work, ''Home'', ''Business'', ''Delivery'' etc.)', 'VARCHAR2(4000)', '''Home''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 22, 'PREFERRED_CONTACT', 'If true, indicates that is the preferred Contact Medium', 'NUMBER(1,0)', '0', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 23, 'PREFERRED_NOTIFICATION', 'If true, indicates that Contact Medium is preferred as notification', 'NUMBER(1,0)', '0', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 24, 'CITY', 'City', 'VARCHAR2(4000)', 'pd.CITY', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 25, 'COUNTRY', 'County', 'VARCHAR2(4000)', 'pd.COUNTRY', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 26, 'EMAIL_ADDRESS', 'Email Address', 'VARCHAR2(4000)', 'pd.EMAIL_ADDRESS', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 27, 'PHONE_EXT_NUMBER', 'Phone extension', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 28, 'POSTCODE', 'The postcode', 'VARCHAR2(4000)', '''111222333''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 29, 'STATE_OR_PROVINCE', 'State or province', 'VARCHAR2(4000)', '''None''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 30, 'STREET1', 'Describes the street', 'VARCHAR2(4000)', 'pd.STREET', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 31, 'STREET2', 'Complementary street description', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 32, 'FAX_NUMBER', 'Fax number', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 33, 'VALID_FROM', 'Contact Medium valid from date.', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 34, 'VALID_TO', 'Contact Medium valid to date.', 'TIMESTAMP(6)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 35, 'EXTENDED_ATTRIBUTES', 'Additional attributes related to Contact Medium.', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 36, 'PHONE_NUMBER', 'The primary phone number', 'VARCHAR2(4000)', 'pd.PHONE_NR', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 37, 'IDB_CUSTOMER_ID', 'Internal : Technical Field for dependency validations', 'VARCHAR2(4000)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 38, 'TO_BE_MIGRATED', 'Flag shows whether customer needs to be migrated or not as per Merge solution', 'CHAR(1)', '''Y''', 'NO', NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 4, 39, 'ID', 'ID', 'RAW(16)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 5, 15, 'CONTACT_MEDIUM_ID', 'Foreign key from IDB_PH1_CIM_CONTACT_MEDIUM', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 5, 16, 'DAY_OF_WEEK', 'Day of week when you can contact the customer', 'VARCHAR2(50)', '''Monday''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 5, 17, 'START_TIME', 'Time from which you can contact the customer', 'VARCHAR2(50)', '''10:00''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 5, 18, 'END_TIME', 'Time until which you can contact the customer', 'VARCHAR2(50)', '''18:00''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 14, 'INDIVIDUAL_ID', 'Primary Key ID', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 15, 'GIVEN_NAME', 'First name', 'VARCHAR2(4000)', 'pd.NAME', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 16, 'FAMILY_NAME', 'Last name', 'VARCHAR2(4000)', 'pd.LAST_NAME', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 17, 'ARISTOCRATIC_TITLE', 'A name that describes someone''s aristocratic position, such as Baron, Graf, Earl, and so forth', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 18, 'FAMILY_GENERATION', 'An abbreviation or word that pertains to the generation in a family, such Sr, Jr', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 19, 'FAMILY_NAME_PREFIX', 'Notes: e.g. Van den, Von etc.', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 20, 'FORM_OF_ADDRESS', 'Contains the Salutation,e.g. Mr., Mrs., Hon., Dr.,Major, etc. Note: Also known as person title Also includes. Miss, Ms', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 21, 'FORMATTED_NAME', 'A formatted name useful for specific contexts (Chinese, Japanese, Korean, …)', 'VARCHAR2(4000)', 'pd.NAME ||'' ''|| pd.LAST_NAME', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 22, 'GENERATION', 'An abbreviation or word that pertains to the generation in a family history, such as Sr., Jr., III (the third), and so forth', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 23, 'MIDDLE_NAME', 'Middle name(s) or initial(s) Note: Multiple fields may be entered with a delimiter in-between or stored in a collection', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 24, 'LEGAL_NAME', 'Contains, in one string, a fully formatted name with all of its pieces in their proper place. This includes all of the necessary punctuation Note: if NULL, then derive from the other fields using name policy', 'VARCHAR2(4000)', 'pd.NAME ||'' ''|| pd.LAST_NAME', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 25, 'PREFERRED_GIVEN_NAME', 'Contains the chosen name by which the person prefers to be addressed. Note: This name may be a name other than a given name, such as a nickname', 'VARCHAR2(4000)', 'pd.NAME', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 26, 'QUALIFICATIONS', 'Contains the letters used to describe academic or other type qualifications held by a person and/or the distinctions conferred upon them. e.g. PhD, MD, CPA, MCSD, etc. Note: also known as orders, decorations, honors, awards and distinctions', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 6, 30, 'ID', 'ID', 'RAW(16)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 15, 'INDIVIDUAL_ID', 'Primary Key ID. Unique identifier of the record', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 16, 'IDENTIFICATION_TYPE', 'Identification type (passport, national identity card, driver’s license, social security number, birth certificate)', 'VARCHAR2(4000)', '''Passport''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 17, 'IDENTIFICATION_NUMBER', 'Unique identifier for the Identification', 'VARCHAR2(4000)', 'pd.CUSTOMER_SOURCE_ID||''#''||rownum', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 18, 'ISSUE_DATE', 'The date when Individual Identification was produced / printed', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 19, 'ISSUING_AUTHORITY', 'Authority which has issued the identifier (chamber of commerce…)', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 20, 'VALID_FROM', 'Identification vaild from date', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 21, 'VALID_TO', 'Identification vaild to date', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 26, 'EXTENDED_ATTRIBUTES', 'Extended parameters', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 7, 27, 'ID', 'ID', 'RAW(16)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 14, 'SOURCE_ID', 'Primary Key ID', 'VARCHAR2(255)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 19, 'ENGAGED_PARTY_ID', 'Unique identifier of a Party on the basis of which the Party Role was created', 'VARCHAR2(4000)', 'pd.CUSTOMER_SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 22, 'ENGAGED_PARTY_REF_TYPE', 'Type of a Party on the basis of which the Party Role was created. E.g. Individual, Organization', 'VARCHAR2(4000)', '''Individual''', '''Individual''; ''Organization''', NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 23, 'EXTENDED_ATTRIBUTES', 'Map to capture additional attributes of Billing Account.', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 24, 'NAME', 'Party Role name', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 26, 'PARTY_ROLE_TYPE', 'Party Role type', 'VARCHAR2(100)', '''User''', 'Customer Representative; Bill Receiver;User;Ticket Requester;Family member;Payer;Legal Guardian; Legal Owner', NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 28, 'STATUS', 'Party Role status', 'VARCHAR2(4000)', '''Validated''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 29, 'STATUS_REASON', 'Used for explanation on the value of the status lifecycle', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 8, 31, 'SOURCE_TIMESTAMP', 'Timestamp when record is being migrated.', 'TIMESTAMP(6)', 'SYSDATE', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 15, 'REF_ID', 'Reference ID', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 16, 'REF_TYPE', 'Reference type', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 17, 'URL', 'URL', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 18, 'NAME', 'Name', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 19, 'DESCRIPTION', 'Description', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 20, 'HREF', 'Href', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 21, 'TYPE', 'Type', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 22, 'MIME_TYPE', 'Mime-type', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 23, 'SIZE_', 'Size', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 24, 'SIZE_UNIT', 'Size-Unit', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 25, 'VALID_FROM', 'Valid from', 'TIMESTAMP(6)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 9, 26, 'VALID_TO', 'Valid to', 'TIMESTAMP(6)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 15, 'AGREEMENT_ID', 'Agreement id', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 16, 'REF_ID', 'Reference id', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 17, 'REF_TYPE', 'Reference type', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 18, 'REFERRED_AGREEMENT_TYPE', 'Referred Agreement type', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 19, 'NAME', 'Name', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 20, 'HREF', 'Href', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 21, 'ID', 'ID', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 11, 15, 'SOURCE_ID', 'Primary Key ID', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 11, 16, 'REF_ID', 'Unique identifier of the related entity', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 11, 17, 'REF_TYPE', 'Type of the related entity, E.g.:
Customer;
Party Role;
Individual;
Organization.', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 11, 18, 'TEXT', 'Note text', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 11, 19, 'AUTHOR', 'Who wrote/added the note', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 11, 20, 'DATE_', 'Date and time of the note', 'TIMESTAMP(6)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 12, 15, 'REF_ID', 'Reference ID', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 12, 16, 'REF_TYPE', 'Reference type', 'VARCHAR2(4000)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 12, 17, 'CONTACT_MEDIUM_ID', 'Primary key', 'VARCHAR2(255)', 'NULL', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 13, 16, 'ID_FROM', 'Unique identifier of the entity from which the association began', 'VARCHAR2(255)', 'ci.SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 13, 17, 'REF_TYPE_FROM', 'Type of the entity from which the association began. E.g.: Customer, Party Role', 'VARCHAR2(4000)', '''Individual''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 13, 18, 'ID_TO', 'Unique identifier of the entity to which the association leads', 'VARCHAR2(255)', 'CU.SOURCE_ID', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 13, 19, 'REF_TYPE_TO', 'Type of the entity to which the association leads. E.g.: Customer, PartyRole, Individual, Organization', 'VARCHAR2(4000)', '''Organization''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 13, 20, 'ASSOCIATION_NAME', 'Name of the association', 'VARCHAR2(4000)', '''CEO of Organization''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 13, 21, 'ASSOCIATION_ROLE', 'Role of the association', 'VARCHAR2(4000)', '''CEO''', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 15, 'domain', 'domain like CIM,IBS,OSS', 'VARCHAR2(200)', 'domain', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 16, 'be_entity', 'entity_type will be used to map with target be_type later in the nifi', 'VARCHAR2(200)', 'be_entity', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 17, 'be_entity_desc', 'reportable descriptino of the be_type', 'VARCHAR2(200)', 'be_entity_desc', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 18, 'legacy_count', 'kpi', 'VARCHAR2(200)', 'cast (null as number)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 19, 'sdb_count', 'kpi', 'VARCHAR2(200)', '(select count(*) from SDB_PH1_PERSONAL_DETAILS)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 20, 'idb_count', 'kpi', 'VARCHAR2(200)', '(select count(*) from IDB_PH1_CIM_CUSTOMER)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 21, 'valid_idb_count', 'kpi', 'VARCHAR2(200)', '(select count(*) from CT_IDB_PH1_CIM_CUSTOMER)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 14, 22, 'target_count', 'kpi', 'VARCHAR2(200)', 'cast (null as number)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 15, 'domain', 'domain like CIM,IBS,OSS', 'VARCHAR2(200)', 'domain', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 16, 'be_entity', 'entity_type will be used to map with target be_type later in the nifi', 'VARCHAR2(200)', 'be_entity', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 17, 'be_entity_desc', 'reportable descriptino of the be_type', 'VARCHAR2(200)', 'be_entity_desc', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 18, 'legacy_count', 'kpi', 'VARCHAR2(200)', 'cast (null as number)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 19, 'sdb_count', 'kpi', 'VARCHAR2(200)', '(select count(*) from SDB_PH1_PERSONAL_DETAILS)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 20, 'idb_count', 'kpi', 'VARCHAR2(200)', '(select count(*) from IDB_PH1_CIM_INDIVIDUAL)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 21, 'valid_idb_count', 'kpi', 'VARCHAR2(200)', '(SELECT count(*) FROM CT_IDB_PH1_CIM_INDIVIDUAL)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 15, 22, 'target_count', 'kpi', 'VARCHAR2(200)', 'cast (null as number)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 18, 'domain', 'domain like CIM,IBS,OSS, NRM', 'VARCHAR2(200)', 'domain', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 19, 'be_entity', 'entity_type will be used to map with target be_type later in the nifi', 'VARCHAR2(200)', 'be_entity', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 20, 'be_entity_desc', 'reportable descriptino of the be_type', 'VARCHAR2(200)', 'be_entity_desc', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 21, 'legacy_count', 'kpi', 'number', 'legacy_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 22, 'sdb_count', 'kpi', 'number', 'sdb_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 23, 'idb_count', 'kpi', 'VARCHAR2(200)', 'idb_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 24, 'valid_idb_count', 'kpi', 'VARCHAR2(200)', 'valid_idb_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 16, 25, 'target_count', 'kpi', 'VARCHAR2(200)', 'cast (null as number)', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 18, 'domain', 'domain like CIM,IBS,OSS, NRM', 'VARCHAR2(200)', 'domain', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 19, 'be_entity', 'entity_type will be used to map with target be_type later in the nifi', 'VARCHAR2(200)', 'be_entity', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 20, 'be_entity_desc', 'reportable descriptino of the be_type', 'VARCHAR2(200)', 'be_entity_desc', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 21, 'legacy_count', 'kpi', 'number', 'legacy_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 22, 'sdb_count', 'kpi', 'number', 'sdb_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 23, 'idb_count', 'kpi', 'VARCHAR2(200)', 'idb_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 24, 'valid_idb_count', 'kpi', 'VARCHAR2(200)', 'valid_idb_count', NULL, NULL, NULL, '{}' FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 17, 25, 'target_count', 'kpi', 'VARCHAR2(200)', 'cast (null as number)', NULL, NULL, NULL, '{}' FROM DUAL
)
;
COMMIT
;
