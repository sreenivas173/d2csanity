prompt 00_init_mig_execution

SET ECHO ON SQLTERMINATOR ON

-- INIT_MIG_EXECUTION / INIT_MIG_EXECUTION
delete from MIG_EXECUTION_STEP where FLOWFILE_ID = 'd2c_example_IDB_ora.xlsx';
