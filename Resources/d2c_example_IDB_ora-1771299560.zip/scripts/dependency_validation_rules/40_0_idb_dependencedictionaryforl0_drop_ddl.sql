prompt 40_0_idb_dependencedictionaryforl0_drop_ddl

SET ECHO ON SQLTERMINATOR ON

-- 0_IDB_DependenceDictionaryForL0_drop_DDL / 0_IDB_DependenceDictionaryForL0_drop
BEGIN
  FOR I IN (SELECT * FROM USER_OBJECTS WHERE ( OBJECT_NAME LIKE upper('IDB_PH1_CIM_C') || '%') AND (OBJECT_TYPE = 'TABLE' OR OBJECT_TYPE = 'VIEW') )
  LOOP
    EXECUTE IMMEDIATE 'DROP '||I.OBJECT_TYPE||' '||I.OBJECT_NAME;
  END LOOP;
END;
/
