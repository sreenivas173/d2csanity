BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE sdb_indoor_spaces';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;  -- \/

CREATE TABLE sdb_indoor_spaces 
AS
SELECT  no2.OBJECT_ID, no2.NAME, no2.DESCRIPTION, no2.OBJECT_ID AS PARENT_ID
FROM  NC_OBJECTS no2 
WHERE EXISTS (SELECT NULL FROM nc_objects no1
     WHERE no1.PARENT_ID = no2.OBJECT_ID
     AND no1.object_type_id+0 = 10025 /* Rack */ )
  AND no2.OBJECT_TYPE_ID  = 7121158695013985788 /* Provider Location */
  AND no2.project_id+0 = 9152709697713933490 -- \/

ALTER TABLE sdb_indoor_spaces 
ADD CONSTRAINT sdb_indoor_spaces_pk PRIMARY KEY (object_id); -- \/