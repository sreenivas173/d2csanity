CREATE OR REPLACE PACKAGE pkg_migr_management AS

  c_default_limit CONSTANT PLS_INTEGER := 100;

  TYPE batch_info IS RECORD (
    number_of_batches NUMBER,
    total_rows NUMBER,    -- was total_rows
    min_batch number,  
    max_batch number,
    lvl varchar2(100)
    ); 

  TYPE batch_ids IS RECORD (
    object_id NUMBER,
    batch_id NUMBER);

  TYPE batch_tbl IS TABLE OF
    pkg_migr_management.batch_info;

  TYPE batch_data_tbl IS TABLE OF
    pkg_migr_management.batch_ids;

  FUNCTION get_batch_tbl_name (
    p_descriptor_id in VARCHAR2,
    p_configuration_id in VARCHAR2)
  RETURN VARCHAR2;

  FUNCTION get_batches_amount (
    p_descriptor_id in VARCHAR2,
    p_configuration_id in VARCHAR2,
    p_get_only_first_batch IN VARCHAR2 DEFAULT null,
    p_level VARCHAR2 DEFAULT NULL)
  RETURN pkg_migr_management.batch_tbl PIPELINED;

  FUNCTION pipe_batch_data (
    p_descriptor_id in VARCHAR2,
    p_configuration_id in VARCHAR2,
    p_batch_id in PLS_INTEGER)
  RETURN pkg_migr_management.batch_data_tbl PIPELINED;

  PROCEDURE log_str(
    p_str VARCHAR2, 
    p_descriptor VARCHAR2 DEFAULT null,
    p_configuration VARCHAR2 DEFAULT null);

END pkg_migr_management;
/ -- \/

CREATE OR REPLACE PACKAGE BODY pkg_migr_management
IS
  PROCEDURE log_str(
    p_str VARCHAR2, 
    p_descriptor VARCHAR2 DEFAULT null, 
    p_configuration VARCHAR2 DEFAULT null)
  AS
    pragma autonomous_transaction;
  BEGIN
    BEGIN
      EXECUTE IMMEDIATE 'CREATE TABLE t(col clob, descriptor varchar2(4000), configuraton varchar2(4000), ts timestamp default systimestamp)';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE != -955 THEN
          RAISE;
        END IF;
    END;
    EXECUTE IMMEDIATE 
      'insert into t (col, descriptor, configuraton) values (:1, :2, :3 )' 
      USING p_str, p_descriptor, p_configuration;
    COMMIT;
  END;

  FUNCTION get_batch_tbl_name (
    p_descriptor_id in VARCHAR2,
    p_configuration_id in VARCHAR2)
    return VARCHAR2
  IS 
  BEGIN
    RETURN 
      case when p_descriptor_id is not null then
        translate(p_configuration_id || '_' || p_descriptor_id  , 
          '- ~!@#$%^&*()+=/\{}:â€;â€™<,>.\?', '_____________________________')
        else translate(p_configuration_id, 
          '- ~!@#$%^&*()+=/\{}:â€;â€™<,>.\?', '_____________________________') || '_scope'
      end;
  END get_batch_tbl_name;

  FUNCTION get_batches_amount (
    p_descriptor_id in VARCHAR2,
    p_configuration_id in VARCHAR2,
    p_get_only_first_batch IN VARCHAR2 DEFAULT NULL,
    p_level IN VARCHAR2 DEFAULT NULL)
  RETURN pkg_migr_management.batch_tbl PIPELINED
  AS
    v_rw batch_info;
    TYPE REF_cursor IS REF CURSOR;
    v_cursor REF_cursor;
    c_sql varchar2(4000) := 
      'SELECT max(c.batch_id) as "number_of_batches", count(c.object_id) as "total_rows", ' ||
      'min(c.batch_id) as min_batch, max(c.batch_id) as max_batch, ' ||
       (case when p_level is not null then 'c.level ' else '1' end ) || ' as lvl ' ||
      'FROM ' || pkg_migr_management.get_batch_tbl_name (p_descriptor_id, p_configuration_id) || ' c ' ||
      (CASE WHEN REGEXP_LIKE(p_get_only_first_batch, '^[[:digit:]]+$')
          then 'WHERE c.batch_id <= ' || p_get_only_first_batch ELSE '' 
      END) ||
      (case when p_level is not null then 'GROUP BY c.level' else '' end);
  BEGIN
    OPEN v_cursor FOR c_sql;
    LOOP
      FETCH v_cursor INTO v_rw;
      exit when v_cursor%notfound;
      PIPE ROW(v_rw);
    END LOOP;
    CLOSE v_cursor;
  END get_batches_amount;

  FUNCTION pipe_batch_data(
    p_descriptor_id in VARCHAR2,
    p_configuration_id in VARCHAR2,
    p_batch_id in PLS_INTEGER)
  RETURN pkg_migr_management.batch_data_tbl PIPELINED
  AS
    results_coll pkg_migr_management.batch_data_tbl;
    batch_arr batch_tbl;
    TYPE REF_cursor IS REF CURSOR;
    v_cursor REF_cursor;
    c_sql varchar2(4000) := 'select object_id, batch_id from ' || 
      get_batch_tbl_name (p_descriptor_id, p_configuration_id) || 
      ' c where c.batch_id = :1';
  BEGIN
    OPEN v_cursor FOR c_sql USING p_batch_id;
    LOOP
      FETCH v_cursor BULK COLLECT INTO results_coll 
        LIMIT pkg_migr_management.c_default_limit;
      for i in 1..results_coll.count loop
        PIPE ROW(results_coll(i));
      end loop;
      exit when v_cursor%notfound;
    END LOOP;
    CLOSE v_cursor;
  END pipe_batch_data;

END;
/ -- \/