@scripts/source_data/01_personal_details_ddl.sql
@scripts/source_data/01_billing_acc_inf_ddl.sql
@scripts/source_data/01_table1_ddl.sql
@scripts/source_data/01_table2_ddl.sql
