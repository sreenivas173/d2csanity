@scripts/00_init_mig_execution.sql
@scripts/01_source_dictionaries.sql
@scripts/01_common_dictionaries.sql
@scripts/03_common_scripts_init_yes.sql
@scripts/05_validation_rules_dict.sql
@scripts/06_dependency_validation_rules_dict.sql
@scripts/06_gather_fallouts_dict.sql
