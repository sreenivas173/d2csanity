
-- META_TRANSFORMATION_ITEM_DML / META_TRANSFORMATION_ITEM
INSERT INTO META_TRANSFORMATION_ITEM (VERSION_ID, PARENT_ID, SOURCE_ID, COLUMN_NAME, FIELD_DESCRIPTION, DATA_TYPE, TRANSFORMATION, LIST_VALUES, REFERENTIAL_ENTITY, REFERENTIAL_CLAUSE, EXTENDED_ATTRIBUTES)
(
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 15, 'GENDER', 'Gender', 'VARCHAR2(4)', 'trim(upper(pd.GENDER))', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 16, 'NAME', 'First name', 'VARCHAR2(50)', 'trim(pd.NAME)', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 17, 'LAST_NAME', 'Last name', 'VARCHAR2(50)', 'trim(pd.LAST_NAME)', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 18, 'CUSTOMER_NR', 'Customer number', 'NUMBER(22)', 'pd.CUSTOMER_NR', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 19, 'LOCATION', 'Location', 'VARCHAR2(170)', 'trim(pd.LOCATION)', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 20, 'VALUE', 'reserved', 'NUMBER', 'null', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 21, 'CUSTOMER_SOURCE_ID', 'Source descriptor', 'VARCHAR2(200)', 'NVL2(pd.CUSTOMER_NR,''Cust#''||to_char(pd.CUSTOMER_NR), NULL)', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 22, 'PHONE_NR', NULL, 'NUMBER(13)', 'REGEXP_REPLACE(pd.PHONE_NR, ''[+ ()''||chr(93),'''')', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 23, 'COUNTRY', 'Country', 'VARCHAR2(20)', 'pd.COUNTRY', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 24, 'CITY', 'City', 'VARCHAR2(30)', 'pd.CITY', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 25, 'STREET', 'Street', 'VARCHAR2(50)', 'pd.STREET', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 26, 'BIRTHDAY', 'Birthday', 'DATE', 'pd.BIRTHDAY', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 27, 'EMAIL_ADDRESS', 'Email address', 'VARCHAR2(4000)', 'pd.EMAIL_ADDRESS', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":"NO"}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 28, 'STATUS', 'Status', 'VARCHAR2(18)', 'pd.STATUS', NULL, NULL, NULL, TO_CLOB('{"BA Comments":"","VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 13, 'ACCOUNT_NR', 'Account number', 'NUMBER', 'bai.ACCOUNT_NR', NULL, NULL, NULL, TO_CLOB('{"VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 14, 'CUSTOMER_NR', 'Customer number', 'NUMBER', 'bai.CUSTOMER_NR', NULL, NULL, NULL, TO_CLOB('{"VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 15, 'CUSTOMER_SOURCE_ID', 'Source descriptor', 'VARCHAR2(200)', 'NVL2(bai.CUSTOMER_NR,''Cust#''||to_char(bai.CUSTOMER_NR), NULL)', NULL, NULL, NULL, TO_CLOB('{"VALIDATE":""}') FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 16, 'STATUS', NULL, 'VARCHAR2(200)', 'bai.STATUS', NULL, NULL, NULL, TO_CLOB('{"VALIDATE":""}') FROM DUAL
)
/
COMMIT
/
