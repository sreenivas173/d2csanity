
-- META_SOURCE_ITEM_DML / META_SOURCE_ITEM
INSERT INTO META_SOURCE_ITEM (VERSION_ID, PARENT_ID, SOURCE_ID, COLUMN_NAME, FIELD_DESCRIPTION, DATA_TYPE)
(
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 4, 'CUSTOMER_NR', 'Customer number', 'NUMBER(22)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 5, 'CUSTOMER_TYPE', 'Customer type', 'VARCHAR2(32)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 6, 'NAME', 'First name', 'VARCHAR2(50)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 7, 'LAST_NAME', 'Last name', 'VARCHAR2(50)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 8, 'BIRTHDAY', 'Birthday', 'DATE' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 9, 'GENDER', 'Gender', 'CHAR(4)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 10, 'EMAIL_ADDRESS', 'Email Address', 'VARCHAR2(70)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 11, 'PHONE_NR', 'Phone Number', 'VARCHAR2(25)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 12, 'LOCATION', 'Location', 'VARCHAR2(170)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 13, 'COUNTRY', 'Country', 'VARCHAR2(20)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 14, 'CITY', 'City', 'VARCHAR2(30)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 15, 'STREET', 'Street', 'VARCHAR2(50)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 16, 'HOUSE_NR', 'House Number', 'NUMBER(22)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 17, 'CUSTOMER_ID', 'Source descriptor', 'VARCHAR2(200)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 18, 'STATUS', 'Status', 'VARCHAR2(18)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 4, 'ACCOUNT_NR', 'Account number', 'NUMBER(9)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 5, 'CUSTOMER_NR', 'Customer number', 'NUMBER(10)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 6, 'START_DATE', 'Creation timestamp', 'DATE' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 7, 'STATUS', 'Account status', 'VARCHAR2(18)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 8, 'BALANCE', 'Balance', 'NUMBER(9,2)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 3, 3, 'CUSTOMER_NR', 'Customer number', 'NUMBER(22)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 3, 4, 'CUSTOMER_TYPE', 'Customer type', 'VARCHAR2(32)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 4, 5, 'CUSTOMER_NR', 'Customer number', 'NUMBER(22)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 4, 6, 'CUSTOMER_TYPE', 'Customer type', 'VARCHAR2(32)' FROM DUAL
)
/
COMMIT
/
