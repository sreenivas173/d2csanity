
-- META_SOURCE_DICT_ITEM_DML / META_SOURCE_DICT_ITEM
INSERT INTO META_SOURCE_DICT_ITEM (VERSION_ID, PARENT_ID, SOURCE_ID, COLUMN_NAME, FIELD_DESCRIPTION, DATA_TYPE)
(
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 5, 'ID', 'Template id', 'NUMBER' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 6, 'NAME', 'Template name', 'VARCHAR2(200)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 7, 'SHORT_NAME', 'Migration id', 'VARCHAR2(2)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 1, 8, 'MIGR_VALUE', 'Indicates if it is Top level offer', 'VARCHAR2(1)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 0, 'SDB_VALUE', NULL, 'VARCHAR2(200)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 2, 1, 'BSS_VALUE', NULL, 'VARCHAR2(200)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 3, 0, 'SDB_VALUE', NULL, 'VARCHAR2(200)' FROM DUAL
 UNION ALL
SELECT 'd2c_example_SDB_oracle.xlsx', 3, 1, 'BSS_VALUE', NULL, 'VARCHAR2(200)' FROM DUAL
)
/
COMMIT
/
