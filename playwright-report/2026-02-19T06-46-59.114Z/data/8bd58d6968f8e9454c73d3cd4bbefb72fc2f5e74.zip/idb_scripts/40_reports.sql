\i idb_scripts/reports/40_idb_d2c_contact_key_ddl.sql
\i idb_scripts/reports/40_idb_d2c_customer_key_ddl.sql
\i idb_scripts/reports/40_idb_d2c_individual_key_ddl.sql
\i idb_scripts/reports/40_idb_d2c_user_tables_ddl.sql
\i idb_scripts/reports/40_idb_d2c_fallout_report_ddl.sql
\i idb_scripts/reports/40_idb_d2c_fallout_report_detail_ddl.sql
\i idb_scripts/reports/40_idb_d2c_flt_entity_ddl.sql
\i idb_scripts/reports/40_idb_d2c_colligate_fallout_ddl.sql
