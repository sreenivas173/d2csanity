
-- sql/extract_indoor_space / 
SELECT  no2.OBJECT_ID, no2.NAME, no2.DESCRIPTION, no2.OBJECT_ID AS PARENT_ID
FROM TABLE(pkg_migr_management.pipe_batch_data(:descriptor_id, :configuration_id, :batch_id)) b
JOIN sdb_indoor_spaces no2 
   ON (no2.OBJECT_ID  = b.object_id)
