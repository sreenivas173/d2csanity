
-- sql/extract_region / 
SELECT obj.object_id, obj.object_id as parent_id, 'CBT Region' as name, 'region' as type, 'country' as parent_basetype, obj.description
FROM TABLE(pkg_migr_management2.pipe_batch_data(
    :configuration_id, :batch_id, :descriptor_id)) s 
join oss_regions obj on (s.object_id = obj.object_id)
