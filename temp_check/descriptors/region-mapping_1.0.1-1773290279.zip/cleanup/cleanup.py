import json
import logging
from migrpy import MigrPy
from migrpy.rest import RestClient, MethodType
migr_py: MigrPy
log: logging.Logger
_headers = {'Content-Type': 'application/json'}
# endpoint is taken from cleanupEndpoint variable of excel-migration-types.json settings file.
ci_filter = "/location-manager/v1/restconf/data/{type}?filter=[{{\"property\":\"mkey\",\"operator\":\"in\",\"value\":{mkeis}}}]"

def remove_objects_from_target_system(base_url: str, path: str):
    rest_client = RestClient()
    try:
        response = rest_client.request(
            MethodType.DELETE,
            base_url,
            path,
            headers=_headers)
        log.error(f'request was successfully processed with response: \n{response}')
    except Exception as e:
        log.error(f"cannot remove data from target: {e}")
        raise e

def prepare_mkey(migrObject):
    mkeis = []
    for o in migrObject:
        mkeis.append(o['data']['region'][0]['mkey'])
    return mkeis

def cleanup_master_system():
    migrObject = migr_py.get_resource("migrated-data").data
    mkeis = prepare_mkey(migrObject)
    ci_url = RestClient.prepare_oss_url("consolidated-inventory-storage."+os.environ['NS_ENV'], "8080")
    remove_objects_from_target_system(ci_url, ci_filter.format(type=migr_py.migr_type, mkeis=urllib.parse.quote_plus(json.dumps(mkeis))))
    return \
        {
            "resources": {
                "cleanup-result": "ok"
            }
        }

if __name__ == '__main__':
    migr_py = MigrPy('region')
    log = migr_py.logger
    res_json = cleanup_master_system()
    print(json.dumps(res_json))
