
-- sql/mdc_technical_retry / 
SELECT td.data, td.batch_id, td.migr_id, td.migr_type FROM transformed_data td
WHERE td.migr_type = @migr_type
AND ed.batch_id = ANY(@batch_id) AND td.status in ('in-progress', 'failed')
