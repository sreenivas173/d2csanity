
-- sql/extract_wire_center / 
SELECT obj.object_id, obj.parent_id, obj.name, 'city' as type, 'region' as parent_basetype
FROM TABLE(pkg_migr_management.pipe_batch_data(:descriptor_id, :configuration_id, :batch_id)) b
JOIN sdb_wire_centers obj
   on (obj.object_id = b.object_id)
