
-- sql/perform_batching_and_get_estimation / 
SELECT number_of_batches, total_rows
  FROM TABLE(pkg_migr_management.get_batches_amount(:descriptor_id, :configuration_id, :get_first_batch))
