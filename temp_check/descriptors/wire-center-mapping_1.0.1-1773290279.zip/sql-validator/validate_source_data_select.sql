
-- sql-validator/validate_source_data_select / 
SELECT
    migr_id,
    'wire-center' as migr_type,
    'source-validation' as migr_step,
    val_id,
    val_name,
    val_type,
    val_category,
    val_message,
    val_description,
    coalesce(lower(severity), 'major') severity,
    wrong_value
FROM (
SELECT 'WIRE_CENTER_NAME_NOT_UNIQUE' as val_id,
      '' as val_name,
      'unique' as val_type,
      'Business' val_category,
      'Example rule: "name" is unique under wire-center' val_description,
      'row id '||row_id as val_message,
      CAST(source_descriptor AS VARCHAR(200)) as migr_id,
      severity,
      wrong_value
 FROM WIRE_CENTER_NAME_NOT_UNIQUE
) fr; -- \/
