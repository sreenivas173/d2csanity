
-- sql/extract_provider_location / 
WITH objs AS (
    SELECT 
       no1.object_id object_id,
       no1.name name,
       no1.description description,
       no1.parent_id parent_id,
       a.attr_id,
       coalesce(lv.value, p.value) param_value
    FROM TABLE(pkg_migr_management.pipe_batch_data(:descriptor_id, :configuration_id, :batch_id)) b
    JOIN nc_objects no1
       ON (b.object_id = no1.object_id and b.batch_id = :batch_id)
    LEFT JOIN nc_params p ON (no1.object_id = p.object_id)
    LEFT JOIN nc_attributes a ON (p.attr_id = a.attr_id)
    LEFT JOIN nc_list_values lv ON (lv.list_value_id = p.list_value_id)
)
SELECT r.*, par3.name AS country
FROM objs
   pivot (max(param_value) for attr_id in
      (
          5002 as "Latitude",
          5001 as "Longitude",
          9152807011513068790 as "House Number",
          3092368218013512845 as "Street Prefix Directional",
          3092368218013512846 as "Street Name",
          3092368218013512855 as "Street Suffix",
          9152812878213082110 as "Apartment",
          2062649640013807333 as "City",
          9152796400113015904 as "State",
          2111942743013241141 as "ZIP"
      ) 
   ) r
   JOIN nc_objects par ON (par.object_id = r.object_id)
   LEFT JOIN nc_objects par2 ON (par2.object_id = par.parent_id) 
   LEFT JOIN nc_objects par3 ON (par3.object_id = par2.parent_id AND par3.OBJECT_type_id = 1102872989013434274)
