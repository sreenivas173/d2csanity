import json
import logging
import os
from migrpy import MigrPy, Context
from migrpy.model import Inventory, Configuration, Fallout, MigrationStep, SeverityLevel, Data, ProtoData, Status
from migrpy.rest import RestClient, MethodType

migr_py: MigrPy
log: logging.Logger
_headers = {'Content-Type': 'application/json'}
setting_manager_url = 'http://settings-manager.'+os.environ['NS_ENV']+':8080'
descriptor_create_endpoint = '/location-manager/v1/restconf/data/customer-location'
descriptor_patch_endpoint = '/location-manager/v1/restconf/data/customer-location'
descriptor_name = 'customer-location' # <-- get from descriptor.yaml (id: producthierarchy)
fallout_id = 'MM.'+ descriptor_name + '.python.system'
resource_name = 'valid-transformed-data'
def save_in_inventory(migr_object: dict) -> dict:
    result = {}
    #migr_py.logger.info(f"Create Object")
    try:
        response = migr_py.rest_client.request(
                        MethodType.POST,
                        setting_manager_url, 
                        descriptor_create_endpoint,
                        body=json.dumps(migr_object["data"]),
                        headers=_headers)
        result['operation'] = 'create'
        migr_object['status'] = 'success'
        #migr_py.logger.info(f"POST Request create ; response {response}")
    except Exception as e:
        migr_py.logger.error(f"POST Request: {id}; Exception: {e.message}")
        if 'with key {} already exists'.format(id) in e.message:
            result['operation'] = 'update'
            try:
                response = migr_py.rest_client.request(
                        MethodType.PATCH,
                        setting_manager_url, 
                        descriptor_patch_endpoint.format(id),
                        body=json.dumps(migr_object["data"]), 
                        headers=_headers)
                migr_object['status'] = 'success'
                #print(f"updated service migr_object= {json.dumps(migr_object)}")
                migr_py.logger.error(f"PATCH Request {id}; response {response}")
            except Exception as e:
                migr_py.logger.error(f"PATCH Request {id}; Exception {e}")
                result['error'] = 'Object {} update failed: {}'.format(id, e)
                migr_object['status'] = 'failed'
        else:
            result['error'] = e
            migr_object['status'] = 'failed'
        pass
        result['error'] = str(e)
        migr_object['status'] = 'failed'
    return {'data': migr_object, 'status': result}

def load_data(transformed_data: list[dict]) -> ([],list[ProtoData], list[Fallout]):
    data = []
    success_data =[]
    fallout_list = list[Fallout]()
    failed_objects = set()
    if transformed_data is not None:
        for obj in transformed_data:
            #migr_py.logger.info(f"Transformed data : {obj}")
            result = save_in_inventory(obj)
            load_result = result["data"]
            data.append(vendor)
            if load_result["status"] == 'failed':
                fallout_list.append(Fallout(migr_id=str(load_result['migr-id']),
                                            val_id=fallout_id,
                                            val_message=str(result['status']['error']),
                                            trace_id=migr_py.request_info.trace_id,
                                            migr_step=MigrationStep.SAVING,
                                            val_type='Target System',
                                            val_category='mig_system_issue',
                                            severity=SeverityLevel.MAJOR))
                failed_objects.add(str(vendor_result['migr-id']))
            else:
                success_data.append(load_result)
    data_list = build_protodata_list(data)
    return success_data, list(failed_objects), data_list, fallout_list

def build_protodata_list(dict_list: list[dict]) -> list[ProtoData]:
    data_list = list[ProtoData]()
    for data in dict_list:
        data_list.append(
            ProtoData(data["migr-id"], Status(data.get("status"))))
    return data_list

if __name__ == '__main__':
    migr_py = MigrPy(descriptor_name)
    log = migr_py.logger
    transformed_resource = migr_py.get_resource(resource_name).data
    success_data,failed_objects, data, fallout = load_data(transformed_resource)
    #log.info(f"loaded-fallout-data={type(fallout)}")
    migr_py.mdc.update_transformed_data_status(migr_py.session, data=data, fallouts=fallout)
    #log.info(f"Result of load_descriptor {success_data}")
    print(json.dumps(    { "resources": {
        "load-result-data": success_data,   # <-- get load-vendor-data from descriptor.yaml from output: load-result-data
        "load-fallouts": failed_objects     # get from output: name: load-fallouts
    }}))
    log.info("all-done")