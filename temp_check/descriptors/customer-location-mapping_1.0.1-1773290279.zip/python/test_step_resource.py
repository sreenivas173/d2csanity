import json
import sys
import logging 

l = logging.getLogger("migr_py.py")
logging.basicConfig()
l.setLevel("INFO")

context = json.loads(sys.stdin.read())
resources = context.get("resources", {})

def has_data(resource):
    if not resource:
        return False
    data = resource.get("data")
    if data is None:
        return False
    if isinstance(data, (list, dict)) and len(data) == 0:
        return False
    return True

# Get first input with data, or "no Data"
result = "no Data"
for name, resource in resources.items():
    if has_data(resource):
        result = resource.get("data")
        break

l.info(result)

print(json.dumps({"message": "", "resources": {"py-step-res": result}}))