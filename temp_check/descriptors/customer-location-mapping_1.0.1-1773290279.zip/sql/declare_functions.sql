
-- sql/declare_functions / 
DECLARE
  v_table_name constant VARCHAR2(1000) := pkg_migr_management.get_batch_tbl_name(:descriptor_id, :configuration_id);
  v_batch_size pls_integer := :batch_size;
  v_ddl_stmt VARCHAR2(4000) := 
    'create table ' || v_table_name || ' as ' ||
    'SELECT scope.object_id, CEIL (row_number() OVER (ORDER BY scope.object_id) / '|| v_batch_size || ') AS batch_id
    FROM (sdb_customer_locations) scope';
BEGIN
  BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE ' || v_table_name;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
        RAISE;
      END IF;
  END;
 
 EXECUTE IMMEDIATE v_ddl_stmt;
END;
/ -- \/
