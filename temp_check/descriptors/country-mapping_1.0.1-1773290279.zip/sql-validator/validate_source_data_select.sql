
-- sql-validator/validate_source_data_select / 
SELECT
    migr_id,
    'country' as migr_type,
    'source-validation' as migr_step,
    val_id,
    val_name,
    val_type,
    val_category,
    val_message,
    val_description,
    coalesce(lower(severity), 'major') severity,
    wrong_value
FROM (
SELECT 'COUNTRY_NAME_NOT_UNIQUE' as val_id,
      '' as val_name,
      'unique' as val_type,
      'Business' val_category,
      'Example rule: "name" is unique under country' val_description,
      'row id '||row_id as val_message,
      CAST(source_descriptor AS VARCHAR(200)) as migr_id,
      severity,
      wrong_value
 FROM COUNTRY_NAME_NOT_UNIQUE
) fr; -- \/
