
-- sql/extract_country / 
SELECT obj.object_id, obj.parent_id, obj.name, 'country' as type, '' as parent_basetype
FROM oss_countries obj
