
-- sql/perform_batching_and_get_estimation / 
SELECT 1 as number_of_batches, count(1) as total_rows FROM (SELECT * FROM oss_countries) scope
