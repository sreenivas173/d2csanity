
-- META_TRANSFORMATION_DML / META_TRANSFORMATION
INSERT INTO META_TRANSFORMATION (VERSION_ID, SEQUENCE, ID, SOURCE_ID, SHEET_NAME, TABLE_NAME, DOMAIN, PHYSICAL_ORGANIZATION, DDL_EXTENSION, ENTITY_NAME, PRIMARY_KEY, GENERATE_PK, TRANSFORMATION_RULES, DESCRIPTION, POST_TRANSFORMATION_SCRIPT, SOURCE_TABLES, TABLE_PARALLEL, TABLE_PCTFREE)
(
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 1, 3, 'IDB_Level1', 'IDB_PH1_CIM_CUSTOMER', 'CIM', NULL, 'tablespace USERS', 'CUSTOMER:SOURCE_ID', 'SOURCE_ID', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM  CT_SDB_PH1_PERSONAL_DETAILS pd'), 'Table that holds the information about customer entity associated with Party(Individual).', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 2, 4, 'IDB_Level1', 'IDB_PH1_CIM_INDIVIDUAL', 'CIM', NULL, NULL, 'INDIVIDUAL:SOURCE_ID,CUSTOMER:IDB_CUSTOMER_ID', 'SOURCE_ID', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), NULL, NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 3, 5, 'IDB_Level1', 'IDB_PH1_CIM_LANGUAGE_REF', 'CIM', NULL, NULL, NULL, 'NA', NULL, TO_CLOB('SELECT #FIELDS_LIST# FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), 'Table that holds the information about language details.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 4, 6, 'IDB_Level1', 'IDB_PH1_CIM_CONTACT_MED', 'CIM', NULL, NULL, 'CONTACT:SOURCE_ID,IDB_CUSTOMER_ID,CUSTOMER:IDB_CUSTOMER_ID', 'SOURCE_ID', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), NULL, NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 5, 8, 'IDB_Level1', 'IDB_PH1_CIM_CONTACT_HOURS', 'CIM', NULL, NULL, NULL, 'CONTACT_MEDIUM_ID', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), 'The table stores information about Contact Medium association (to be able to link Contact Medium stored on Individual\Organization with their Customer\PartyRoles where party acts as engaged party).', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 6, 9, 'IDB_Level1', 'IDB_PH1_CIM_INDIV_NAME', 'CIM', NULL, NULL, 'INDIVIDUAL:INDIVIDUAL_ID', 'INDIVIDUAL_ID', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), 'Table that holds the information about  Individual''s name Transformations', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 7, 10, 'IDB_Level1', 'IDB_PH1_CIM_INDIV_IDENT', 'CIM', NULL, NULL, 'INDIVIDUAL:INDIVIDUAL_ID', 'INDIVIDUAL_ID,IDENTIFICATION_TYPE,IDENTIFICATION_NUMBER', NULL, TO_CLOB('SELECT  #FIELDS_LIST#  
FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), 'Table that holds the information about Individual''s identification.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 8, 12, 'IDB_Level1', 'IDB_PH1_CIM_PARTY_ROLE', 'CIM', NULL, NULL, 'CUSTOMER:IDB_CUSTOMER_ID', 'NA', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM CT_SDB_PH1_PERSONAL_DETAILS pd'), 'The table stores information about Party Role. Represents roles played by the party.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 9, 13, 'IDB_Level1', 'IDB_PH1_CIM_ATTACHMENT', 'CIM', NULL, NULL, 'CUSTOMER:IDB_CUSTOMER_ID', 'NA', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM dual
WHERE 1<>1'), 'Table that holds the information about attachments.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 10, 14, 'IDB_Level1', 'IDB_PH1_CIM_AGREEMENT_REF', 'CIM', NULL, NULL, 'CUSTOMER:IDB_CUSTOMER_ID', 'NA', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM dual
WHERE 1<>1'), 'Table that holds the information about agreements.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 11, 15, 'IDB_Level1', 'IDB_PH1_CIM_NOTE', 'CIM', NULL, NULL, 'CUSTOMER:IDB_CUSTOMER_ID', 'SOURCE_ID', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM dual
WHERE 1<>1'), 'Table that holds the information about customer''s Contact Medium.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 10, 12, 16, 'IDB_Level1', 'IDB_PH1_CIM_CON_MED_ASSOC', 'CIM', NULL, NULL, 'CUSTOMER:IDB_CUSTOMER_ID', 'NA', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM dual
WHERE 1<>1'), 'Table that holds the information about contact medium association details.', NULL, 'CT_SDB_PH1_PERSONAL_DETAILS', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 20, 13, 3, 'IDB_Level2', 'IDB_PH1_CIM_PTY_ROLE_ASC', 'CIM', NULL, NULL, 'CUSTOMER:IDB_CUSTOMER_ID', 'NA', NULL, TO_CLOB('SELECT #FIELDS_LIST#
FROM IDB_PH1_CIM_INDIVIDUAL CI,
     IDB_PH1_CIM_CUSTOMER CU,
  IDB_PH1_CIM_PARTY_ROLE PR
WHERE  CI.SOURCE_ID = CU.SOURCE_ID
  AND PR.ENGAGED_PARTY_ID = CI.SOURCE_ID'), 'Table that holds the information about customer credit profile details.', NULL, 'IDB_PH1_CIM_INDIVIDUAL,IDB_PH1_CIM_CUSTOMER,IDB_PH1_CIM_PARTY_ROLE', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 50, 14, 3, 'IDB_PostFallout_Level1', 'KPI_BSS_CUSTOMER', 'CIM', NULL, NULL, NULL, 'domain,be_entity', NULL, TO_CLOB('select #FIELDS_LIST# FROM
(
select ''CIM'' as domain, 
       ''Customer'' as be_entity,
       ''Customer'' as be_entity_desc
from dual
)'), NULL, NULL, 'SDB_PH1_PERSONAL_DETAILS,IDB_PH1_CIM_CUSTOMER,CT_IDB_PH1_CIM_CUSTOMER', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 50, 15, 4, 'IDB_PostFallout_Level1', 'KPI_BSS_INDIVIDUAL', 'CIM', NULL, NULL, NULL, 'domain,be_entity', NULL, TO_CLOB('select #FIELDS_LIST# FROM
(
select ''CIM'' as domain, 
       ''Individual'' as be_entity,
       ''Individual'' as be_entity_desc
from dual
)'), NULL, NULL, 'SDB_PH1_PERSONAL_DETAILS,IDB_PH1_CIM_INDIVIDUAL,CT_IDB_PH1_CIM_INDIVIDUAL', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 51, 16, 3, 'IDB_PostFallout_Level2', 'KPI_REPORT', NULL, NULL, NULL, NULL, 'domain,be_entity', NULL, TO_CLOB('select #FIELDS_LIST# FROM (select * from KPI_BSS_CUSTOMER
union all
select * from KPI_BSS_INDIVIDUAL)'), NULL, TO_CLOB('alter table KPI_REPORT add (per_cent number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL); alter table KPI_REPORT add (per_cent2 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL); alter table KPI_REPORT add (per_cent3 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL); '), 'KPI_BSS_CUSTOMER,KPI_BSS_INDIVIDUAL', 0, 0 FROM DUAL
 UNION ALL
SELECT 'd2c_example_IDB_ora_Srini.xlsx', 51, 17, 4, 'IDB_PostFallout_Level2', 'KPI_REPORT2', NULL, NULL, NULL, NULL, 'domain,be_entity', NULL, TO_CLOB('select #FIELDS_LIST# FROM (select * from KPI_BSS_CUSTOMER
union all
select * from KPI_BSS_INDIVIDUAL)'), NULL, TO_CLOB('alter table KPI_REPORT2 add (per_cent number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL); alter table KPI_REPORT2 add (per_cent2 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL); alter table KPI_REPORT2 add (per_cent3 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL); '), 'KPI_BSS_CUSTOMER,KPI_BSS_INDIVIDUAL', 0, 0 FROM DUAL
)
/
COMMIT
/
