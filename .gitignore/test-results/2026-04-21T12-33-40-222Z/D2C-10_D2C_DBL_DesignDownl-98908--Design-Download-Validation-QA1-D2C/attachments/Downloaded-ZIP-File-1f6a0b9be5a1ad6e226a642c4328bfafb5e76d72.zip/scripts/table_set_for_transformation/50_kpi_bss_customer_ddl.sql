
-- KPI_BSS_CUSTOMER_DDL / KPI_BSS_CUSTOMER
DROP TABLE IF EXISTS KPI_BSS_CUSTOMER CASCADE
/

-- KPI_BSS_CUSTOMER_DDL / KPI_BSS_CUSTOMER
CREATE TABLE KPI_BSS_CUSTOMER AS
select 
	domain as DOMAIN,
	be_entity as BE_ENTITY,
	be_entity_desc as BE_ENTITY_DESC,
	cast (null as number) as LEGACY_COUNT,
	(select count(*) from SDB_PH1_PERSONAL_DETAILS) as SDB_COUNT,
	(select count(*) from IDB_PH1_CIM_CUSTOMER) as IDB_COUNT,
	(select count(*) from CT_IDB_PH1_CIM_CUSTOMER) as VALID_IDB_COUNT,
	cast (null as number) as TARGET_COUNT FROM
(
select 'CIM' as domain, 
       'Customer' as be_entity,
       'Customer' as be_entity_desc
from dual
);

-- KPI_BSS_CUSTOMER_DDL / KPI_BSS_CUSTOMER
core/gather_table_stats;
