
-- KPI_REPORT2_DDL / KPI_REPORT2
DROP TABLE IF EXISTS KPI_REPORT2 CASCADE
/

-- KPI_REPORT2_DDL / KPI_REPORT2
CREATE TABLE KPI_REPORT2 AS
select 
	domain as DOMAIN,
	be_entity as BE_ENTITY,
	be_entity_desc as BE_ENTITY_DESC,
	legacy_count as LEGACY_COUNT,
	sdb_count as SDB_COUNT,
	idb_count as IDB_COUNT,
	valid_idb_count as VALID_IDB_COUNT,
	cast (null as number) as TARGET_COUNT FROM (select * from KPI_BSS_CUSTOMER
union all
select * from KPI_BSS_INDIVIDUAL);

-- KPI_REPORT2_DDL / KPI_REPORT2
DO $$DECLARE
BEGIN
    EXECUTE $q$ map[LeftDel:[ RightDel:] SQLItem:alter table KPI_REPORT2 add (per_cent number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL)] $q$;
END$$;
;
/

-- KPI_REPORT2_DDL / KPI_REPORT2
DO $$DECLARE
BEGIN
    EXECUTE $q$ map[LeftDel:[ RightDel:] SQLItem:alter table KPI_REPORT2 add (per_cent2 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL)] $q$;
END$$;
;
/

-- KPI_REPORT2_DDL / KPI_REPORT2
DO $$DECLARE
BEGIN
    EXECUTE $q$ map[LeftDel:[ RightDel:] SQLItem:alter table KPI_REPORT2 add (per_cent3 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL)] $q$;
END$$;
;
/

-- KPI_REPORT2_DDL / KPI_REPORT2
core/gather_table_stats;
