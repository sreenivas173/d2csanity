
-- IDB_D2C_USER_TABLES_DDL / IDB_D2C_USER_TABLES
DROP TABLE IF EXISTS IDB_D2C_USER_TABLES CASCADE
/

-- IDB_D2C_USER_TABLES_DDL / IDB_D2C_USER_TABLES
CREATE TABLE IDB_D2C_USER_TABLES(TABLE_NAME, NUM_ROWS) AS
SELECT UPPER(table_name), f_column_count_distinct(table_name, 'ctid') FROM information_schema.tables
WHERE table_schema = current_schema() and table_type = 'BASE TABLE'
  AND (table_name in (
  	select lower(table_name) from META_SOURCE
  	union all
  	select lower(table_name) from META_TRANSFORMATION
  	union all
  	select lower(table_name) from META_SOURCE_DICT
  ) or table_name~'^(mj|mi).*');
