timing start "Total time"
set define on
		
column cur_date new_value cur_date noprint
select to_char(sysdate, 'YYYYMMDD_HH24MI') cur_date from dual;
		
spool 00_idb_d2c_meta_initialization_&cur_date
		
set feedback on
set time on
set sqlblanklines on
set define off
@meta/00_meta_d2c_version_dml.sql
@meta/00_meta_transformation_dml.sql
@meta/00_meta_transformation_item_dml.sql
set sqlterminator on echo on
prompt Found errors
select distinct type, name from user_errors;
timing show
spool off