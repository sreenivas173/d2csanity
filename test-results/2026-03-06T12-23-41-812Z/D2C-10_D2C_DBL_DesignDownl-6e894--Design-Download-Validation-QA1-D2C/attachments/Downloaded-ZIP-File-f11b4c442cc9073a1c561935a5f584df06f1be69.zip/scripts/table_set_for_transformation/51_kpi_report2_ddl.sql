prompt 51_kpi_report2_ddl

SET ECHO ON SQLTERMINATOR ON

-- KPI_REPORT2_DDL / KPI_REPORT2
BEGIN
  FOR I IN (SELECT * FROM USER_OBJECTS WHERE OBJECT_NAME=upper('KPI_REPORT2'))
  LOOP
    EXECUTE IMMEDIATE 'DROP '||I.OBJECT_TYPE||' '||I.OBJECT_NAME;
  END LOOP;
END;
/

-- KPI_REPORT2_DDL / KPI_REPORT2
CREATE TABLE KPI_REPORT2  PCTFREE 0 NOLOGGING AS
select 
	domain as DOMAIN,
	be_entity as BE_ENTITY,
	be_entity_desc as BE_ENTITY_DESC,
	legacy_count as LEGACY_COUNT,
	sdb_count as SDB_COUNT,
	idb_count as IDB_COUNT,
	valid_idb_count as VALID_IDB_COUNT,
	cast (null as number) as TARGET_COUNT FROM (select * from KPI_BSS_CUSTOMER
union all
select * from KPI_BSS_INDIVIDUAL);

-- KPI_REPORT2_DDL / KPI_REPORT2
BEGIN
    EXECUTE IMMEDIATE q'[alter table KPI_REPORT2 add (per_cent number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL)]';
END;
/

-- KPI_REPORT2_DDL / KPI_REPORT2
BEGIN
    EXECUTE IMMEDIATE q'[alter table KPI_REPORT2 add (per_cent2 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL)]';
END;
/

-- KPI_REPORT2_DDL / KPI_REPORT2
BEGIN
    EXECUTE IMMEDIATE q'[alter table KPI_REPORT2 add (per_cent3 number(10,2) generated always as (case when nvl(idb_count,0)=0 then 0 else ROUND(  ((target_count/idb_count)*100),6) end) VIRTUAL)]';
END;
/
