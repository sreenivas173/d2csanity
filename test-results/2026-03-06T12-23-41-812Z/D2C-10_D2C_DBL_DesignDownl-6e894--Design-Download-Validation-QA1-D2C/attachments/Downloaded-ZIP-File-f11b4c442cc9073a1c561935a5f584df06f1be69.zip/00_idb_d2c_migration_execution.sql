timing start "Total time"
set define on
		
column cur_date new_value cur_date noprint
select to_char(sysdate, 'YYYYMMDD_HH24MI') cur_date from dual;
		
spool 00_idb_d2c_migration_execution_&cur_date
		
set feedback on
set time on
set sqlblanklines on
set define off
@scripts/10_table_set_for_transformation.sql
@scripts/20_table_set_for_transformation.sql
@scripts/30_validation_rules.sql
@scripts/30_gather_fallouts.sql
@scripts/40_dependency_validation_rules.sql
@scripts/40_gather_fallouts.sql
@scripts/40_reports.sql
@scripts/50_table_set_for_transformation.sql
@scripts/51_table_set_for_transformation.sql
set sqlterminator on echo on
prompt Found errors
select distinct type, name from user_errors;
timing show
spool off